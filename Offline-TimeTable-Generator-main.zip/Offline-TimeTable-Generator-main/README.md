# Offline-TimeTable-Generator
Its allow to to design your table
by adding the headers you want in the data.txt file
START FINISH must be provided
also DAY must be provided and be in the first
