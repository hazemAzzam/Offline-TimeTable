#include <iostream>
#include "File.h"
using namespace std;

int main()
{
	File f;
	f.generate();
	system("pause");
}